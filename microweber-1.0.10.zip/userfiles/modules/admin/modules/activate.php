<?php if(!isset($params['prefix'])): ?>
<?php return; ?>
<?php endif; ?>


<module type="settings/group/license_edit" prefix="<?php print $params['prefix'] ?>" />

 