<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class App extends \Illuminate\Support\Facades\App
{

}