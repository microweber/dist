<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Redis extends \Illuminate\Support\Facades\Redis
{

}