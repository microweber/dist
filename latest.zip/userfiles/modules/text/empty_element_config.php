<?php

$config = array();
$config['name'] = "Empty Element";
$config['author'] = "Microweber";
$config['description'] = "Microweber";
$config['website'] = "http://microweber.com/";
$config['help'] = "http://microweber.info/modules/title";
$config['version'] = 0.2;
$config['ui'] = true;
$config['position'] = 8;
$config['as_element'] = 1;
$config['categories'] = "content";


