<?php

class UserBase
{
}
