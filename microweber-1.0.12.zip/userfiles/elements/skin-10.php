<div class="mw-static-element mw-features-boxes" id="head-image-<?php print CONTENT_ID; ?>">
    <h2>How it Works?</h2>
    <br/>
    <div class="mw-ui-row">
        <div class="mw-ui-col cloneable">
            <div class="mw-ui-row">
                <div class="mw-ui-col" style="width: 35px;">
                    <div class="number text-primary">1.</div>
                </div>
                <div class="mw-ui-col">
                    <div class="text">
                        <h4>We love our customers</h4>
                        <p>Template layout is ready for edit in ream time with Microweber.
                            How to Be Creative. Creativity is a skill that you can work on with time, training, and effort. There are many areas you can focus on to improve your overall
                            creativity.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="mw-ui-col cloneable">
            <div class="mw-ui-row">
                <div class="mw-ui-col" style="width: 35px;">
                    <div class="number text-primary">2.</div>
                </div>
                <div class="mw-ui-col">
                    <div class="text">
                        <h4>Your website your way</h4>
                        <p>Template layout is ready for edit in ream time with Microweber.
                            How to Be Creative. Creativity is a skill that you can work on with time, training, and effort. There are many areas you can focus on to improve your overall
                            creativity.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="mw-ui-col cloneable">
            <div class="mw-ui-row">
                <div class="mw-ui-col" style="width: 35px;">
                    <div class="number text-primary">3.</div>
                </div>
                <div class="mw-ui-col">
                    <div class="text">
                        <h4>Let’s go to the space</h4>
                        <p>Template layout is ready for edit in ream time with Microweber.
                            How to Be Creative. Creativity is a skill that you can work on with time, training, and effort. There are many areas you can focus on to improve your overall
                            creativity.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>