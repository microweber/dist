<div class="mw-static-element mw-text-under-image" id="mw-text-under-image-<?php print CONTENT_ID; ?>">
    <div class="mw-ui-row">
        <div class="mw-ui-col cloneable">
            <div class="mw-image">
                <img src="<?php print elements_url() ?>images/default-4.jpg"/>
            </div>
            <div class="mw-text">
                <p>
                    Template layout is ready for edit in ream time with Microweber.<br/>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look
                    even
                    slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum
                    generators on
                    the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined
                </p>
            </div>
        </div>

        <div class="mw-ui-col cloneable">
            <div class="mw-image">
                <img src="<?php print elements_url() ?>images/default-5.jpg"/>
            </div>
            <div class="mw-text">
                <p>
                    Template layout is ready for edit in ream time with Microweber.<br/>
                    There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look
                    even
                    slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum
                    generators on
                    the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined
                </p>
            </div>
        </div>
    </div>
</div>
