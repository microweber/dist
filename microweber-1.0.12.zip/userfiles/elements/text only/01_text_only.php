
<h2 class="element layout-title lipsum">Simple Text</h2>
<p class="element layout-paragraph lipsum"><?php print lipsum(); ?></p>
