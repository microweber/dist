<?php

$config = array();
$config['name'] = "Breadcrumb";
$config['description'] = "Breadcrumb navigation";
$config['author'] = "Microweber";
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = 54;
$config['version'] = 0.2;
