$(document).ready(function () {
    $('.faq-holder.styled .item').on('click', function () {
        // if ($(this).hasClass('closed')){

        // }
        $(this).toggleClass('closed');
    });
});