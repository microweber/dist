<img class="element img-polaroid" style="width: 100%" src="<?php print pixum(800,120); ?>" />
<div class="mw-row">
  <div class="mw-col" style="width: 30%">
    <div class="mw-col-container">
      <div class="well element" style="padding-bottom: 0">
        <module type="categories" class="nav nav-pills" for="content" />
      </div>
    </div>
  </div>
  <div class="mw-col" style="width: 70%">
    <div class="mw-col-container">
      <h2 class="element layout-title lipsum">Simple Text</h2>
      <p class="element layout-paragraph lipsum">
          <?php print lipsum(); ?>
      </p>
    </div>
  </div>
</div>
