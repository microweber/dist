<?php

$config = array();
$config['name'] = "Image, text, categories and banners.";
$config['author'] = "Microweber";
$config['description'] = "Header Image with categories text and banners.";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "blog, custom";
$config['version'] = 0.7;
$config['position'] = 17;
$config['as_element'] = true;
