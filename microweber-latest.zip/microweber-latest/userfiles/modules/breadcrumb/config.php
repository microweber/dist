<?php

$config = array();
$config['name'] = "Breadbrumb navigation";
$config['author'] = "Microweber";
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = 70;
$config['version'] = 0.1;
