<?php

$config = array();
$config['name'] = "Audio";
$config['author'] = "Microweber";
$config['description'] = "Microweber";
$config['website'] = "http://microweber.com/";
$config['help'] = "http://microweber.info/modules/audio";
$config['version'] = 0.19;
$config['ui'] = true;
$config['position'] = 18;


$config['categories'] = "media";


