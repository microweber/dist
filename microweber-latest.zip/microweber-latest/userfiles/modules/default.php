<p>This is a sample module: </p>
<pre><?php print_r($params) ?></pre>
