<?php

$config = array();
$config['name'] = "Custom fields";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = false;
$config['ui_admin'] = false;
$config['position'] = 15;
$config['is_system'] = true;



