<?php

$config = array();
$config['name'] = "Pay on delivery";
$config['author'] = "D.Velev (colocation.bg)";
$config['author.2'] = "Microweber";
$config['ui'] = false;
$config['categories'] = "online shop";
$config['position'] = 130;
$config['type'] = "payment_gateway";
 
