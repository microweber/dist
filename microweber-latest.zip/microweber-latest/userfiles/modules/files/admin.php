 
<?php include_once($config['path_to_module'].'admin_backend.php'); ?>
 