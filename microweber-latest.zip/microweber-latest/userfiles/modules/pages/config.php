<?php

$config = array();
$config['name'] = "Pages Menu";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "menus";
$config['position'] = "15";
$config['version'] = 1.2;
$config['is_system'] = true;
