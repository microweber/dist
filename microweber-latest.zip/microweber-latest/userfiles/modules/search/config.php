<?php

$config = array();
$config['name'] = "Search";
$config['author'] = "Microweber";
$config['description'] = "Module to search for content";
$config['website'] = "http://microweber.com/"; 
$config['help'] = "http://microweber.info/modules/search"; 
$config['version'] = 0.2;
$config['ui'] = true;
$config['position'] = 20; 
$config['categories'] = "content";


