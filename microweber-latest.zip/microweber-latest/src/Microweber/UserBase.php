<?php

class UserBase
{

}