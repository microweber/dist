<?php


class Fields extends BaseModel
{

    public $table = 'media';

    public static function boot()
    {
        parent::boot();
    }

}

