<?php


class DataFields extends BaseModel
{

    public $table = 'content_data';



}

