<?php

namespace Microweber\tests;

class OthrerTest extends TestCase {
    public function testOtherFunctions() {

        $file = 'test.php';
        $file2 = 'test.php.';
        $ext = get_file_extension($file);
        $ext2 = get_file_extension($file2);
        $this->assertEquals('php', $ext);
        $this->assertEquals('php', $ext2);

        $ext = no_ext($file);
        $ext2 = no_ext($file2);
        $this->assertEquals('test', $ext);
        $this->assertEquals('test', $ext2);

    }


}