<?php return array (
  'is_installed' => 1,
  'install_default_template' => 'default',
  'install_default_template_content' => 1,
  'compile_assets' => 1,
  'has_admin' => 1,
);