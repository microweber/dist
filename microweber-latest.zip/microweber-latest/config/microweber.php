<?php return array (
  'compile_assets' => 1,
  'has_admin' => 1,
  'is_installed' => 1,
);