<?php return array (
  'version' => '1.0.7',
  'install_default_template' => 'liteness',
  'install_default_template_content' => 1,
  'compile_assets' => 1,
  'has_admin' => 1,
  'is_installed' => 1,
);