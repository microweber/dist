# Unit tests

[Tests are located here](../src/Microweber/tests/ "")
 