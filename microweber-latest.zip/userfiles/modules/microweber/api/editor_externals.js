

    $(window).load(function(){
      $(mwd.body).removeClass('mw-external-loading');
    });










