<div class="mw-notification mw-success">
    <div>
    <?php _e($text); ?>
    </div>
  </div>