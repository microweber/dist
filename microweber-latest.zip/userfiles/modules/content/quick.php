<?php
 include('edit.php');
 return;
  