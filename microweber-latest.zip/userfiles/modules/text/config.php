<?php

$config = array();
$config['name'] = "Text";
$config['author'] = "Microweber";
$config['description'] = "Simple text";
$config['version'] = 0.2;
$config['ui'] = true;
$config['position'] = 2; 
$config['as_element'] = 1;
$config['categories'] = "content, recommended";


