<?php

$config = array();
$config['name'] = "Ants";
$config['link'] = "https://github.com/tomphp/jquery.insects";
$config['description'] = "Ferocious ants for your website!";
$config['author'] = "Tom Oram";
$config['author_website'] = "http://devblog.x2k.co.uk/";
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = "28";
$config['version'] = 0.05;
