<?php

function antzz()
{
    exit('antzz is here!!!');
}


