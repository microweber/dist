


<span class="mw_editor_btn" onclick="mw.drag.module_settings(document.getElementById('mw-editor-global-styles-btn'))">ED</span>