<?php

$config = array();
$config['name'] = "Global Styles";
$config['description'] = " Theme styles configurator";
$config['author'] = "Microweber";

$config['ui_admin'] = false;
$config['ui'] = false;


$config['categories'] = "editor";
$config['position'] = 200;
$config['version'] = 0.3;