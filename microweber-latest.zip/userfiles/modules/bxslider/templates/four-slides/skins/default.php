<a href="<?php if (isset($slide['url'])) { print $slide['url']; } ?>" style="background-image: url('<?php print $slide['images'][0]; ?>');"></a>
