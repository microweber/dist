<?php


$config = array();

$config['name'] = "bxSlider";

$config['author'] = "Microweber";

$config['version'] = "0.1";

$config['no_cache'] = true;
$config['ui'] = true;
$config['ui_admin'] = false;
$config['position'] = 12;

 