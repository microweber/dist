<?php

$config = array();
$config['name'] = "Logo";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = 7;
$config['version'] = 1;