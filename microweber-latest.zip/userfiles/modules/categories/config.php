<?php

$config = array();
$config['name'] = "Categories";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['position'] = 16;
$config['categories'] = "navigation";
$config['version'] = 0.1;
$config['is_system'] = true;

