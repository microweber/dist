<?php only_admin_access(); ?>
 <module type="categories/manage" id="mw-cats-manage-admin" />