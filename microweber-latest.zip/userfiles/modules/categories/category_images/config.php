<?php

$config = array();
$config['name'] = "Categories Images";
$config['author'] = "Microweber";
$config['version'] = "0.1";
$config['ui'] = true;
$config['position'] = 51;

?>
