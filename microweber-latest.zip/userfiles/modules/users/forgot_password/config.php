<?php

$config = array();
$config['name'] = "Forgot password";
$config['author'] = "Microweber";
$config['description'] = "Microweber";
$config['website'] = "http://microweber.com/"; 
$config['help'] = "http://microweber.info/modules/users/registration"; 
$config['version'] = 0.2;
$config['ui'] = true; 
   $config['position'] = 23;
$config['categories'] = "users";    

 