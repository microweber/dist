<?php

/*

type: layout

name: Default

description: Testimonials Default

*/

?>
<?php
print lnotif('Click here to select layout');
?>