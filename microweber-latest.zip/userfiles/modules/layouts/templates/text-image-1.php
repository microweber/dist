<?php

/*

type: layout

name: Text image 1 - left



*/
?>

<div class="edit" field="layout-skin-5-<?php print $params['id'] ?>" rel="layout">
    <div class="text-image-layout-1 left" id="text-image-left-<?php print CONTENT_ID; ?>">
        <div class="image">
            <div class="mw-image-holder">
                <img src="http://lorempixel.com/800/410" alt=""/>
                <span class="mw-image-holder-overlay"></span>
                <div class="mw-image-holder-content" style=""></div>
            </div>
        </div>
        <div class="info">
            <h4>Our Experience</h4>
            <p>
                It is a long est`ablished fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a
                more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
            </p>
        </div>
    </div>
</div>