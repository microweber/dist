<?php

/*

type: layout

name: Services 1

 
 
*/
?>

<div class="edit" field="layout-skin-3-<?php print $params['id'] ?>" rel="layout">
    <div class="row services-layout-1">
        <div class="">
            <div class="col-xs-12 col-md-6 service">
                <h3><i class="fa fa-refresh"></i> Money Sharing With Friends and Family.</h3>
                <p>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has
                    typesetting, remaining essentially unchanged.
                </p>
            </div>

            <div class="col-xs-12 col-md-6 service">
                <h3><i class="fa fa-refresh"></i> Money Sharing With Friends and Family.</h3>
                <p>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has
                    typesetting, remaining essentially unchanged.
                </p>
            </div>

            <div class="col-xs-12 col-md-6 service">
                <h3><i class="fa fa-refresh"></i> Money Sharing With Friends and Family.</h3>
                <p>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has
                    typesetting, remaining essentially unchanged.
                </p>
            </div>

            <div class="col-xs-12 col-md-6 service">
                <h3><i class="fa fa-refresh"></i> Money Sharing With Friends and Family.</h3>
                <p>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has
                    typesetting, remaining essentially unchanged.
                </p>
            </div>
        </div>
    </div>
</div>
