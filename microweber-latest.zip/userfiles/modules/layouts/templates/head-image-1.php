<?php

/*

type: layout

name: Head image 1



*/
?>
<div class="edit" field="layout-skin-2-<?php print $params['id'] ?>" rel="layout">
    <div class="head-image-layout-1" id="head-image-<?php print CONTENT_ID; ?>">
        <div class="mw-image-holder">
            <img src="http://lorempixel.com/1200/410" alt=""/>
            <span class="mw-image-holder-overlay"></span>
            <div class="mw-image-holder-content" style="">
                <div class="content-holder">
                    <div class="inner">
                        <h1>Our Services</h1>
                        <p>Be assured, our services and team members will support your business growth</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>