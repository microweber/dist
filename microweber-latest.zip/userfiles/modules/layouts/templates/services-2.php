<?php

/*

type: layout

name: Services 2

 
 
*/
?>

<div class="edit" field="layout-skin-4-<?php print $params['id'] ?>" rel="layout">
    <div class="services-layout-2">
        <div class="text-center">
            <h2 class="special">What we do</h2>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 service">
                <i class="fa fa-refresh"></i>
                <h3>Green energy</h3>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.
                </p>
                <module type="btn" text="Learn more..." id="button-1"/>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4 service">
                <i class="fa fa-refresh"></i>
                <h3> Constructions</h3>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry . Lorem Ipsum has been the industry .
                </p>
                <module type="btn" text="Learn more..." id="button-2"/>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4 service">
                <i class="fa fa-refresh"></i>
                <h3> Business Consulting </h3>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry . Lorem Ipsum has been the industry .
                </p>
                <module type="btn" text="Learn more..." id="button-3"/>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4 service">
                <i class="fa fa-refresh"></i>
                <h3> Accounting</h3>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry . Lorem Ipsum has been the industry .
                </p>
                <module type="btn" text="Learn more..." id="button-4"/>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4 service">
                <i class="fa fa-refresh"></i>
                <h3> Lower Services </h3>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry . Lorem Ipsum has been the industry .
                </p>
                <module type="btn" text="Learn more..." id="button-5"/>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4 service">
                <i class="fa fa-refresh"></i>
                <h3> Payment Methods </h3>
                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry . Lorem Ipsum has been the industry .
                </p>
                <module type="btn" text="Learn more..." id="button-6"/>
            </div>
        </div>
    </div>
</div>
