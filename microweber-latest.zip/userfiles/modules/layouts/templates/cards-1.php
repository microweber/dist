<?php

/*

type: layout

name: Cards 1

 

*/
?>

<div class="edit" field="layout-skin-1-<?php print $params['id'] ?>" rel="layout">
    <div class="cards-layout-1">
        <div class="info-text center p-t-30">
            <h1 class="m-b-10">Best In Financial & Payment Services</h1>
            <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a
                galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially
                unchanged.
            </p>
        </div>

        <div class="row cards">
            <div class="card col-xs-12 col-lg-4">
                <div class="icon-wrapper"><span class="fa fa-refresh"></span></div>
                <div class="card-block">
                    <h4 class="card-title">Virtual Wallet</h4>
                    <p class="card-text">Lorem Ipsum is simply dummy text
                        of the printing and typesetting industry.

                    </p>
                    <module type="btn" text="Read More" button_style="btn-primary" id="button-1"/>
                </div>
            </div>

            <div class="card col-xs-12 col-lg-4">
                <div class="icon-wrapper"><span class="fa fa-refresh"></span></div>
                <div class="card-block">
                    <h4 class="card-title">Virtual Wallet</h4>
                    <p class="card-text">Lorem Ipsum is simply dummy text
                        of the printing and typesetting industry.

                    </p>
                    <module type="btn" text="Read More" button_style="btn-primary" id="button-2"/>
                </div>
            </div>

            <div class="card col-xs-12 col-lg-4">
                <div class="icon-wrapper"><span class="fa fa-refresh"></span></div>
                <div class="card-block">
                    <h4 class="card-title">Virtual Wallet</h4>
                    <p class="card-text">Lorem Ipsum is simply dummy text
                        of the printing and typesetting industry.

                    </p>
                    <module type="btn" text="Read More" button_style="btn-primary" id="button-3"/>
                </div>
            </div>
        </div>
    </div>
</div>
