<?php

$config = array();
$config['name'] = "Accordion";
$config['author'] = "Microweber";
$config['ui'] = true;
$config['version'] = 0.01;
$config['categories'] = "accordion";
$config['position'] = 52;

