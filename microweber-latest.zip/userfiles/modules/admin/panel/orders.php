<module type="admin/panel/shop/orders" />
