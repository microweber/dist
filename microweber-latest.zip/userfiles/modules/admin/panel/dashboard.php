<module type="admin/panel/shop/dashboard" />
