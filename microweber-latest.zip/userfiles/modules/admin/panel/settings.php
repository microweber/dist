<module type="admin/panel/shop/settings" />
