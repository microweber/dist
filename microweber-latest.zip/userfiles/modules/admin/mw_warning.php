<div class="mw-notification mw-warning">
    <div>
    <?php _e($text); ?>
    </div>
  </div>