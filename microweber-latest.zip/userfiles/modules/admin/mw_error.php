<div class="mw-notification mw-error">
    <div>
    <?php _e($text); ?>
    </div>
  </div>