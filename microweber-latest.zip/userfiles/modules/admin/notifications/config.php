<?php
$config = array();
$config['name'] = "Notifications";
$config['author'] = "Microweber";

$config['categories'] = "admin";
$config['version'] = 0.3;
$config['ui_admin'] = false;
$config['is_system'] = true;

$config['position'] = 50;



