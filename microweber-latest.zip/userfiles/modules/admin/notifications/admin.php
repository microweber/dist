<div class="mw-module-admin-wrap"> <?php if(isset($params['backend'])): ?>
<module type="admin/modules/info" />
<?php endif; ?><?php include($config['mp'].'index.php'); ?></div>