<?php 


namespace updates; 



 
class Api extends \MwController {
	public $return_data = false;
	public $page_url = false;
	public $create_new_page = false;
	public $render_this_url = false;
	public $isolate_by_html_id = false;

	function indddex() {
		
		  print rand();
	}
}
 
   