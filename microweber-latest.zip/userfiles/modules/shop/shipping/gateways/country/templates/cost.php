<?php

/*

type: layout

name: Shipping cost

description: Shipping cost value

*/
?>

  <span class="shipping_cost"><?php print currency_format($shipping_cost); ?></span>  
