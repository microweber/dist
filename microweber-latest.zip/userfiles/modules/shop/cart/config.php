<?php

$config = array();
$config['name'] = "Shopping Cart";
$config['author'] = "Microweber";
 
$config['ui'] = true;
 
$config['categories'] = "online shop";
$config['version'] = 0.24;
$config['position'] = "14";


