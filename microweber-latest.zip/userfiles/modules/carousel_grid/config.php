<?php

$config = array();
$config['name'] = "Carousel Grid";
$config['author'] = "Microweber";
$config['description'] = "Microweber Carousel Grid";
$config['website'] = "http://microweber.com/";
$config['version'] = 1;
$config['ui'] = true;
$config['position'] = 100;


$config['categories'] = "media";


