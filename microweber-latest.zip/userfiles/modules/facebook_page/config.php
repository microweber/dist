<?php

$config = array();
$config['name'] = "Facebook page";
$config['link'] = "https://microweber.com";
$config['description'] = "Facebook page integration for your website!";
$config['author'] = "";
$config['author_website'] = "";
$config['ui'] = true;
$config['ui_admin'] = false;
$config['categories'] = "other";
$config['position'] = "100";
$config['version'] = 0.01;
