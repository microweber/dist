<?php



$config = array();

$config['name'] = "Magic Slider";

$config['author'] = "Microweber";

$config['version'] = "0.1";



$config['position'] = 13;
