<div class="module-live-edit-settings">
    <module type="admin/modules/templates"/>
</div>