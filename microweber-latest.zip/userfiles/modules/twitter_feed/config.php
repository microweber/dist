<?php

$config = array();
$config['name'] = "Twitter feed";
$config['link'] = "https://microweber.com";
$config['description'] = "Feed of tweets";
$config['author'] = "Peter Ivanov";
$config['author_website'] = "https://microweber.com";
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = "120";
$config['version'] = 0.01;
