<?php

$config = array();
$config['name'] = "Files";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = false;
$config['ui_admin'] = true;
$config['categories'] = "media";
$config['position'] = 20;
$config['version'] = 0.2;


