<?php

$config = array();
$config['name'] = "Google Maps";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "other";
$config['version'] = 0.3;
$config['position'] = 24;


