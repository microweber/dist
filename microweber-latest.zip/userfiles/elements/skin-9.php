<div class="mw-static-element mw-image-and-text" id="image-and-text-<?php print CONTENT_ID; ?>">
    <div class="mw-ui-row">
        <div class="mw-ui-col cloneable">
            <div class="image">
                <img src="<?php print elements_url() ?>images/default-2.png" alt=""/>
            </div>
        </div>
        <div class="mw-ui-col cloneable">
            <div class="text">
                <h1>Our Services</h1>
                <p>Template layout is ready for edit in ream time with Microweber.<br/>
                    How to Be Creative. Creativity is a skill that you can work on with time, training, and effort. There are many areas you can focus on to improve your overall creativity.
                </p>
                <module type="btn" text="Button"/>
            </div>
        </div>
    </div>
</div>