<?php

$config = array();
$config['name'] = "Text 2 columns";
$config['author'] = "Microweber";
$config['description'] = "Text 2 columns";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "simple, recommended";
$config['position'] = 2;
$config['version'] = 0.2;
$config['as_element'] = true;
 