<div class="mw-static-element mw-icons-with-info" id="mw-icons-with-info-<?php print CONTENT_ID; ?>">
    <div class="mw-ui-row">
        <div class="mw-ui-col cloneable">
            <div class="mw-icon">
                <i class="fa icon-Add-UserStar mw-wysiwyg-custom-icon text-primary"></i>
            </div>
            <div class="mw-text">
                <h4>We love our customers</h4>
                <p>
                    Template layout is ready for edit in ream time with Microweber. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some
                    form, by injected humour, or randomised words which don't look even slightly believable.
                </p>
            </div>
        </div>

        <div class="mw-ui-col cloneable">
            <div class="mw-icon">
                <i class="fa icon-Approved-Window mw-wysiwyg-custom-icon text-primary"></i>
            </div>
            <div class="mw-text">
                <h4>We love our customers</h4>
                <p>
                    Template layout is ready for edit in ream time with Microweber. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some
                    form, by injected humour, or randomised words which don't look even slightly believable.
                </p>
            </div>
        </div>

        <div class="mw-ui-col cloneable">
            <div class="mw-icon">
                <i class="fa icon-Astronaut mw-wysiwyg-custom-icon text-primary"></i>
            </div>
            <div class="mw-text">
                <h4>We love our customers</h4>
                <p>
                    Template layout is ready for edit in ream time with Microweber. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some
                    form, by injected humour, or randomised words which don't look even slightly believable.
                </p>
            </div>
        </div>
    </div>
</div>
