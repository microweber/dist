<?php

$config = array();
$config['name'] = "4 Pictures";
$config['author'] = "Microweber";
$config['description'] = "4 pictures in 2 columns";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "gallery, online shop, portfolio";
$config['version'] = 0.2;
$config['position'] = 11;
$config['as_element'] = true;
$config['layout_type'] = "dynamic";