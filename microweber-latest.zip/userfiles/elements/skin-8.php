<div class="mw-static-element mw-head-100vh-image" id="head-100vh-image-<?php print CONTENT_ID; ?>">
    <div class="mw-image-holder" style="background-image: url('<?php print elements_url() ?>images/default-12.jpg');">
        <img src="<?php print elements_url() ?>images/default-12.jpg" alt=""/>
        <span class="mw-image-holder-overlay"></span>
        <div class="mw-image-holder-content" style="">
            <div class="content-holder">
                <div class="inner">
                    <h1>Our Services</h1>
                    <p>Template layout is ready for edit in ream time with Microweber.<br/>
                        How to Be Creative. Creativity is a skill that you can work on with time, training, and effort. There are many <br/> areas you can focus on to improve your overall creativity.
                    </p>
                    <module type="btn" text="Button"/>
                </div>
            </div>
        </div>
    </div>
</div>