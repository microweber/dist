<?php

$config = array();
$config['name'] = "Double - floated image with paragraph";
$config['author'] = "Microweber";
$config['description'] = "Two elements with floated image(on the left) and a paragraph (on the right)";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "gallery, online shop, recommended";
$config['version'] = 0.1;
$config['position'] = 42;
$config['as_element'] = true;
