<?php

$config = array();
$config['name'] = "Image Categories Text";
$config['author'] = "Microweber";
$config['description'] = "Widescreen image with categories on the bottom right and text on the bottom left side.";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "recomended,custom,blog";
$config['version'] = 0.1;
$config['position'] = 44;
$config['as_element'] = true;