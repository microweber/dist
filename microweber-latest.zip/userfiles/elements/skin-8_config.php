<?php

$config = array();
$config['name'] = "Full screen Background Image with text";
$config['author'] = "Microweber";
$config['description'] = "";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "custom";
$config['version'] = 0.1;
$config['position'] = 8;
$config['as_element'] = true;
