<?php

$config = array();
$config['name'] = "Text & Button in Backgrounded Box ";
$config['author'] = "Microweber";
$config['description'] = "Simple backgrounded box with text and button inside";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "custom";
$config['version'] = 0.1;
$config['position'] = 4;
$config['as_element'] = true;
