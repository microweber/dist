<div class="well">
  <div class="mw-row">
    <div class="mw-col" style="width:35%" >
      <div class="mw-col-container">
           <img class="element img-polaroid" src="<?php print pixum(450,150); ?>"  />
      </div>
    </div>
    <div class="mw-col" style="width:65%" >
        <div class="mw-col-container">
              <h2 class="element lipsum">Simle title</h2>
              <p class="element lipsum">
                  <?php print lipsum(); ?>
              </p>
        </div>
    </div>
  </div>
</div>
<div class="well">
  <div class="mw-row">
    <div class="mw-col" style="width:35%" >
      <div class="mw-col-container">
           <img class="element img-polaroid" src="<?php print pixum(450,150); ?>"  />
      </div>
    </div>
    <div class="mw-col" style="width:65%" >
        <div class="mw-col-container">
              <h2 class="element lipsum">Simle title</h2>
              <p class="element lipsum">
                  <?php print lipsum(); ?>
              </p>
        </div>
    </div>
  </div>
</div>


