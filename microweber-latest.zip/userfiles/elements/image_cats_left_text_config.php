<?php

$config = array();
$config['name'] = "Image Categories Text";
$config['author'] = "Microweber";
$config['description'] = "Widescreen image with categories on the bottom left and text.";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "custom, blog";
$config['version'] = 0.5;
$config['position'] = 13;
$config['as_element'] = true;
