<div class="mw-static-element mw-head-image" id="head-image-<?php print CONTENT_ID; ?>">
    <div class="mw-image-holder" style="background-image: url('<?php print elements_url() ?>images/default-6.jpg');">
        <img src="<?php print elements_url() ?>images/default-6.jpg" alt=""/>
        <span class="mw-image-holder-overlay"></span>
        <div class="mw-image-holder-content" style="">
            <div class="content-holder">
                <div class="inner">
                    <h1>Our Services</h1>
                    <p>Be assured, our services and team members will support your business growth</p>
                    <module type="btn" text="Button" />
                </div>
            </div>
        </div>
    </div>
</div>