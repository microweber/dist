
<div class="mw-row">
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
      <div class="thumbnail">
        <div class="caption">
           <h2 class="element lipsum">Picture title</h2>
           <img class="element img-polaroid" src="<?php print pixum(400,150); ?>"  />
           <p class="element lipsum"><?php print lipsum(); ?></p>
        </div>
      </div>
    </div>
  </div>
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
      <div class="thumbnail">
        <div class="caption">
           <h2 class="element lipsum">Picture title</h2>
           <img class="element img-polaroid" src="<?php print pixum(400,150); ?>"  />
           <p class="element lipsum"><?php print lipsum(); ?></p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="mw-row">
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
      <div class="thumbnail">
        <div class="caption">
           <h2 class="element lipsum">Picture title</h2>
           <img class="element img-polaroid" src="<?php print pixum(400,150); ?>"  />
           <p class="element lipsum"><?php print lipsum(); ?></p>
        </div>
      </div>
    </div>
  </div>
  <div class="mw-col" style="width:50%">
    <div class="mw-col-container">
      <div class="thumbnail">
        <div class="caption">
           <h2 class="element lipsum">Picture title</h2>
           <img class="element img-polaroid" src="<?php print pixum(400,150); ?>"  />
           <p class="element lipsum"><?php print lipsum(); ?></p>
        </div>
      </div>
    </div>
  </div>
</div>
