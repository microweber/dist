<div class="mw-static-element mw-vertical-centered-text-and-image" id="text-image-left-<?php print CONTENT_ID; ?>">
    <div class="image">
        <div class="mw-image-holder" style="background-image: url('<?php print elements_url() ?>images/default-1.jpg');">
            <img src="<?php print elements_url() ?>images/default-1.jpg" alt=""/>
            <span class="mw-image-holder-overlay"></span>
        </div>
    </div>
    <div class="info">
        <h4>Our Experience</h4>
        <p>
            It is a long est`ablished fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a
            more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
        </p>
        <module type="btn" text="Button" />
    </div>
</div>


<div class="mw-static-element mw-vertical-centered-text-and-image" id="text-image-right-<?php print CONTENT_ID; ?>">
    <div class="info">
        <h4>Our Experience</h4>
        <p>
            It is a long est`ablished fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a
            more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
        </p>
        <module type="btn" text="Button" />
    </div>

    <div class="image">
        <div class="mw-image-holder" style="background-image: url('<?php print elements_url() ?>images/default-7.jpg');">
            <img src="<?php print elements_url() ?>images/default-7.jpg" alt=""/>
            <span class="mw-image-holder-overlay"></span>
        </div>
    </div>
</div>

