<?php

$config = array();
$config['name'] = "Image + Text";
$config['author'] = "Microweber";
$config['description'] = "";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "custom";
$config['version'] = 0.1;
$config['position'] = 9;
$config['as_element'] = true;
