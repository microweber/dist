<?php

$config = array();
$config['name'] = "Team";
$config['author'] = "Microweber";
$config['description'] = "Team";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "portfolio";
$config['version'] = 1.0;
$config['position'] = 19;
$config['as_element'] = true;
