
<div class="mw-row">
  <div class="mw-col" style="width:25%" >
    <div class="mw-col-container">
        <img class="element img-polaroid img-rounded" src="<?php print pixum(150, 150); ?>"    />
    </div>
  </div>
  <div class="mw-col" style="width: 75%">
    <div class="mw-col-container">
      <h2 class="element layout-title lipsum">Simple Text</h2>
      <p class="element lipsum"><?php print lipsum(); ?></p>
      <p class="element lipsum"><?php print lipsum(); ?></p>
    </div>
  </div>
</div>




