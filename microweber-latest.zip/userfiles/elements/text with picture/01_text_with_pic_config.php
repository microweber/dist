<?php

$config = array();
$config['name'] = "Text with picture";
$config['author'] = "Microweber";
$config['description'] = "Text with picture";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "simple, recommended";
$config['position'] = "34";
$config['version'] = "0.1";
$config['as_element'] = true;