<div class="mw-row our-team">
      <div class="mw-col" style="width:25%">
        <div class="mw-col-container">
        	<div class="element" align="center">
        		<img class="element" src="<?php print pixum(170, 170); ?>" height="170" />
        		<p class="element"><strong>Team Member</strong></p>
        		<p class="element"><em>Current Position</em></p>
        		<hr class="visible-desktop element">
        		<p class="element" align="justify">The following text is ready for edit. Click here and describe your company team members briefly.</p>
        		<span class="mw-social-icons-layout-list element">
        			<a href="https://facebook.com/Microweber" class="mw-icon-facebook"></a>
        			<a href="https://twitter.com/Microweber" class="mw-icon-twitter"></a>
        			<a href="https://plus.google.com/+Microweber/" class="mw-icon-googleplus"></a>
        			<a href="https://youtube.com/Microweber" class="mw-icon-social-youtube"></a>
        		</span>
        	</div>
        </div>
      </div>
      <div class="mw-col" style="width:25%">
        <div class="mw-col-container">
        	<div class="element" align="center">
        		<img class="element" src="<?php print pixum(170, 170); ?>" height="170" />
        		<p class="element"><strong>Team Member</strong></p>
        		<p class="element"><em>Current Position</em></p>
        		<hr class="visible-desktop element">
        		<p class="element" align="justify">The following text is ready for edit. Click here and describe your company team members briefly.</p>
        		<span class="mw-social-icons-layout-list element">
        			<a href="https://facebook.com/Microweber" class="mw-icon-facebook"></a>
        			<a href="https://twitter.com/Microweber" class="mw-icon-twitter"></a>
        			<a href="https://plus.google.com/+Microweber/" class="mw-icon-googleplus"></a>
        			<a href="https://youtube.com/Microweber" class="mw-icon-social-youtube"></a>
        		</span>
        	</div>
        </div>
      </div>
      <div class="mw-col" style="width:25%">
        <div class="mw-col-container">
        	<div class="element" align="center">
        		<img class="element" src="<?php print pixum(170, 170); ?>" height="170" />
        		<p class="element"><strong>Team Member</strong></p>
        		<p class="element"><em>Current Position</em></p>
        		<hr class="visible-desktop element">
        		<p class="element" align="justify">The following text is ready for edit. Click here and describe your company team members briefly.</p>
        		<span class="mw-social-icons-layout-list element">
        			<a href="https://facebook.com/Microweber" class="mw-icon-facebook"></a>
        			<a href="https://twitter.com/Microweber" class="mw-icon-twitter"></a>
        			<a href="https://plus.google.com/+Microweber/" class="mw-icon-googleplus"></a>
        			<a href="https://youtube.com/Microweber" class="mw-icon-social-youtube"></a>
        		</span>
        	</div>
        </div>
      </div>
      <div class="mw-col" style="width:25%">
        <div class="mw-col-container">
        	<div class="element" align="center">
        		<img class="element" src="<?php print pixum(170, 170); ?>" height="170" />
        		<p class="element"><strong>Team Member</strong></p>
        		<p class="element"><em>Current Position</em></p>
        		<hr class="visible-desktop element">
        		<p class="element">The following text is ready for edit. Click here and describe your company team members briefly.</p>
        		<span class="mw-social-icons-layout-list element">
        			<a href="https://facebook.com/Microweber" class="mw-icon-facebook"></a>
        			<a href="https://twitter.com/Microweber" class="mw-icon-twitter"></a>
        			<a href="https://plus.google.com/+Microweber/" class="mw-icon-googleplus"></a>
        			<a href="https://youtube.com/Microweber" class="mw-icon-social-youtube"></a>
        		</span>
        	</div>
        </div>
      </div>
</div>