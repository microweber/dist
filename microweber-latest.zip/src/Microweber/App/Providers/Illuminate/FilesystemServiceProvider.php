<?php

namespace Microweber\App\Providers\Illuminate;

class FilesystemServiceProvider extends \Illuminate\Filesystem\FilesystemServiceProvider
{

}


