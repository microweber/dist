<?php

namespace Microweber\App\Providers\Illuminate;

class PaginationServiceProvider extends \Illuminate\Pagination\PaginationServiceProvider
{

}


