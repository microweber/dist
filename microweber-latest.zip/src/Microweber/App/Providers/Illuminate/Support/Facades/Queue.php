<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Queue extends \Illuminate\Support\Facades\Queue
{

}