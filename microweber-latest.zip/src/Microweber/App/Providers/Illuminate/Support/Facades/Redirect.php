<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Redirect extends \Illuminate\Support\Facades\Redirect
{

}