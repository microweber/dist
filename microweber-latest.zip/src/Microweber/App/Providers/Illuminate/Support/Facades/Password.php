<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Password extends \Illuminate\Support\Facades\Password
{

}