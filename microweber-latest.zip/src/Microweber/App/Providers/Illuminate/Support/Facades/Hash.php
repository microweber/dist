<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Hash extends \Illuminate\Support\Facades\Hash
{

}