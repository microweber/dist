<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Mail extends \Illuminate\Support\Facades\Mail
{

}