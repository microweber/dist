<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Auth extends \Illuminate\Support\Facades\Auth
{

}