<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Validator extends \Illuminate\Support\Facades\Validator
{

}