<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Response extends \Illuminate\Support\Facades\Response
{

}