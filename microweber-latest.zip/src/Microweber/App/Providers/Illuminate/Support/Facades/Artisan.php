<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Artisan extends \Illuminate\Support\Facades\Artisan
{

}