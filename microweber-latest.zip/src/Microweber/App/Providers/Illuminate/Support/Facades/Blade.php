<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Blade extends \Illuminate\Support\Facades\Blade
{

}