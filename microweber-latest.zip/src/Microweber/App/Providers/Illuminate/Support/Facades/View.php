<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class View extends \Illuminate\Support\Facades\View
{

}