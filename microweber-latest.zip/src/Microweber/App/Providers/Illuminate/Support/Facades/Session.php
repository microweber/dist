<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Session extends \Illuminate\Support\Facades\Session
{

}