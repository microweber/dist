<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Cache extends \Illuminate\Support\Facades\Cache
{

}