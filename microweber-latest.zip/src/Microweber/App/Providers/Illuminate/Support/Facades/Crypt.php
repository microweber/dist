<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Crypt extends \Illuminate\Support\Facades\Crypt
{

}