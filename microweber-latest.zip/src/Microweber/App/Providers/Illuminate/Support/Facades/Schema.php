<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Schema extends \Illuminate\Support\Facades\Schema
{

}