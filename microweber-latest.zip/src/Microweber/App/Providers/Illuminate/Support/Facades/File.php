<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class File extends \Illuminate\Support\Facades\File
{

}