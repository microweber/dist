<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Lang extends \Illuminate\Support\Facades\Lang
{

}