<?php

namespace Microweber\App\Providers\Illuminate\Support\Facades;

class Request extends \Illuminate\Support\Facades\Request
{

}