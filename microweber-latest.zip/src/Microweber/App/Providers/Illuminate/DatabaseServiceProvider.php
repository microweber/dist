<?php

namespace Microweber\App\Providers\Illuminate;

class DatabaseServiceProvider extends \Illuminate\Database\DatabaseServiceProvider
{

}


