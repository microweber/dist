<?php

namespace Microweber\App\Providers\Illuminate;

class HashServiceProvider extends \Illuminate\Hashing\HashServiceProvider
{

}


