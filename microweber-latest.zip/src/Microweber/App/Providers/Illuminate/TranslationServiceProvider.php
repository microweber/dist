<?php

namespace Microweber\App\Providers\Illuminate;

class TranslationServiceProvider extends \Illuminate\Translation\TranslationServiceProvider
{

}


