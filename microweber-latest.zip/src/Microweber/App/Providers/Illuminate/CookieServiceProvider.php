<?php

namespace Microweber\App\Providers\Illuminate;

class CookieServiceProvider extends \Illuminate\Cookie\CookieServiceProvider
{

}


