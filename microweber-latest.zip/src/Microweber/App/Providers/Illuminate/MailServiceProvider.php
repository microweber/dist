<?php

namespace Microweber\App\Providers\Illuminate;

class MailServiceProvider extends \Illuminate\Mail\MailServiceProvider
{

}


