<?php

namespace Microweber\App\Providers\Illuminate;

class CacheServiceProvider extends \Illuminate\Cache\CacheServiceProvider{

}

