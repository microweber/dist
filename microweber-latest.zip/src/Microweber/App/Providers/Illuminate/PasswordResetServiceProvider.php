<?php

namespace Microweber\App\Providers\Illuminate;

class PasswordResetServiceProvider extends \Illuminate\Auth\Passwords\PasswordResetServiceProvider
{

}


