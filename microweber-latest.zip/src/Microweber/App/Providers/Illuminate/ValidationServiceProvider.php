<?php

namespace Microweber\App\Providers\Illuminate;

class ValidationServiceProvider extends \Illuminate\Validation\ValidationServiceProvider
{

}


