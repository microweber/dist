<?php

namespace Microweber\App\Providers\Illuminate;

class AuthServiceProvider extends \Illuminate\Auth\AuthServiceProvider{

}

