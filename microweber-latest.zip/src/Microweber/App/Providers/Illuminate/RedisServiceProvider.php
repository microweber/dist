<?php

namespace Microweber\App\Providers\Illuminate;

class RedisServiceProvider extends \Illuminate\Redis\RedisServiceProvider
{

}


