<?php namespace Microweber\App\Events;

abstract class Event {

	//

}
