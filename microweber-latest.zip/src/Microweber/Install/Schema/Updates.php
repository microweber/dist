<?php

namespace Microweber\Install\Schema;


use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;


class Updates extends Migration
{


    public function up()
    {




    }

    public function down()
    {



    }

}
