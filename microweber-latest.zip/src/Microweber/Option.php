<?php


class Option extends BaseModel
{
    public $table = 'options';

    public static function boot()
    {
        parent::boot();
    }
}
