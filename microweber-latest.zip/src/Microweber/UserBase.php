<?php

class UserBase
{
}
