
<fieldset class="inputs">
  <legend><span>Posts</span></legend>
  <input name="number_of_posts"   class="mw_option_field"   type="range"  min="3" max="20"  value="<?php print get_option('number_of_posts', $params['id']) ?>">
</fieldset>
