<?php

$config = array();
$config['name'] = "MVC Blade Module";
$config['author'] = "Microweber";
$config['description'] = "Example of MVC";
$config['website'] = "http://microweber.com/"; 
$config['help'] = "http://microweber.com"; 
$config['version'] = 0.1;
$config['ui'] = true;
$config['ui_admin'] = true;
$config['categories'] = "other";
$config['position'] = 100;

