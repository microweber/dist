<?php

$config = array();
$config['name'] = "Login";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['position'] = 22;
$config['version'] = 0.2;
$config['categories'] = "users";





