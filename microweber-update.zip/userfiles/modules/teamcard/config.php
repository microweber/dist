<?php

$config = array();
$config['name'] = "Team Card";
$config['author'] = "Microweber";
$config['ui'] = true;
$config['version'] = 0.01;
$config['position'] = 57;