<a href="<?php if (isset($slide['url'])) {
    print $slide['url'];
} ?>"><img src="<?php print $slide['images'][0]; ?>" alt=""/></a>
