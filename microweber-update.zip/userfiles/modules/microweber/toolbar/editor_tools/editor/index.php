<?php
$here = dirname(dirname(dirname(__FILE__)));
include($here.DS.'wysiwyg.php');
include($here.DS.'wysiwyg_tiny.php');
 

 