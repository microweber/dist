
<h2><?php _e("Done"); ?>, </h2>
<a href="<?php print site_url('admin') ?>"><?php _e("click here to to to admin"); ?></a> <a href="<?php print site_url() ?>"><?php _e("click here to to to site"); ?></a>