<?php 



if (!defined('userfiles_path()')) {
    define('userfiles_path()', MW_ROOTPATH . 'sites' . DIRECTORY_SEPARATOR."{domain}".DIRECTORY_SEPARATOR);
}