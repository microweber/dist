<?php

$data  = array();
$data['id'] = 0;	
$data['data_type'] = 'category';	
$data['title'] = 'Category Name';	
$data['url'] = '';	
$data['parent_id'] = '0';	
$data['content_type'] = '';	
$data['description'] = '';	
$data['rel_type'] = 'content';	
$data['rel_id'] = '';	
$data['position'] = '';	
$data['content'] = '';		
$data['url'] = '';		