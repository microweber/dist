<?php

$config = array();
$config['name'] = "FAQ";
$config['author'] = "Microweber";
$config['ui'] = true;
$config['version'] = 0.01;
$config['position'] = 57;