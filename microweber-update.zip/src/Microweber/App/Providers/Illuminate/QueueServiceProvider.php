<?php

namespace Microweber\App\Providers\Illuminate;

class QueueServiceProvider extends \Illuminate\Queue\QueueServiceProvider
{

}


