<?php

namespace Microweber\App\Providers\Illuminate;

//use Illuminate\Foundation\Providers\ArtisanServiceProvider;
class ArtisanServiceProvider extends \Illuminate\Foundation\Providers\ArtisanServiceProvider{

}


