<?php


class Menu extends BaseModel
{
    public $table = 'menus';

    public static function boot()
    {
        parent::boot();
    }
}
