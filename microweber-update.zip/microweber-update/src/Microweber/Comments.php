<?php


class Comments extends BaseModel
{

    public $table = 'comments';



}

