<table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td>modules_url</td>
    <td><?php print modules_url(); ?></td>
  </tr>
  <tr>
    <td>modules_path</td>
    <td><?php print modules_path(); ?></td>
  </tr>
  <tr>
    <td>userfiles_path</td>
    <td><?php print userfiles_path(); ?></td>
  </tr>
  <tr>
    <td>userfiles_folder</td>
    <td><?php print modules_url(); ?></td>
  </tr>
  <tr>
    <td>site_url</td>
    <td><?php print site_url(); ?></td>
  </tr>
  <tr>
    <td>templates_path</td>
    <td><?php print templates_path(); ?></td>
  </tr>
  <tr>
    <td>templates_url</td>
    <td><?php print templates_url(); ?></td>
  </tr>
</table>
<?php




 



