NON EXISTING MODULE!!!!
 
<?php var_dump($params); ?>