<?php
$config = array();
$config['name'] = "Updates";
$config['author'] = "Microweber";

$config['categories'] = "admin";
$config['version'] = 0.3;
$config['ui_admin'] = true;
$config['position'] = 50;
$config['is_system'] = true;


