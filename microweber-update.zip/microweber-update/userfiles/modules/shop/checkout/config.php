<?php

$config = array();
$config['name'] = "Checkout";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "online shop";
$config['position'] = 13;
$config['version'] = 0.3;


