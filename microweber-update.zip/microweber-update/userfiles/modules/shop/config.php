<?php

$config = array();
$config['name'] = "Online shop";
$config['author'] = "Microweber";
$config['ui_admin'] = false;
$config['ui'] = false;


$config['categories'] = "online shop";
$config['position'] = 2;
$config['version'] = 0.3;