<?php

$config = array();
$config['name'] = "Paypal Pro payment gateway";
$config['author'] = "Microweber";
$config['ui'] = false;
$config['categories'] = "online shop";
$config['position'] = 111;
$config['type'] = "payment_gateway";


