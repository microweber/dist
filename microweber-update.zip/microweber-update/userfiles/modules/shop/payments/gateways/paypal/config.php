<?php

$config = array();
$config['name'] = "Paypal Express payment gateway";
$config['author'] = "Microweber";
$config['ui'] = false;
$config['categories'] = "online shop";
$config['position'] = 110;
$config['type'] = "payment_gateway";
