<?php

 
 
$place_order['order_completed'] = 1;
$place_order['is_paid'] = 0;
$place_order['success'] =  _e('Thank you for your order',true);
