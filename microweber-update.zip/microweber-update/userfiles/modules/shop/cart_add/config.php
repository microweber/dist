<?php

$config = array();
$config['name'] = "Add to cart";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['ui_admin'] = false;
$config['categories'] = "online shop";
$config['version'] = 0.26;
$config['position'] = "14";


