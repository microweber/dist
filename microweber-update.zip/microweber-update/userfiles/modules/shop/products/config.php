<?php

$config = array();
$config['name'] = "Products";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "online shop";
$config['version'] = 0.41;
$config['position'] = 12;


