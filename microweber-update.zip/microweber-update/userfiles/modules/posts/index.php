<?php

$controller = new content\controllers\Front();
return $controller->index($params,$config);