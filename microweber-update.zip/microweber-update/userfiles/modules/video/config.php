<?php

$config = array();
$config['name'] = "Video";
$config['author'] = "Microweber";
$config['categories'] = "media";
$config['position'] = "5";
$config['version'] = 0.1;

$config['no_cache'] = true;
$config['ui'] = true;


