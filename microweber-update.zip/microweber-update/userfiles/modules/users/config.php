<?php
$config = array();
$config['name'] = "Users";
$config['author'] = "Microweber";
$config['ui'] = '0';
$config['ui_admin'] = '1';
$config['is_system'] = true;
//$config['on_install'] = "mw_install_stats_module";
//$config['on_uninstall'] = "mw_uninstall_stats_module";
$config['position'] = 9;
$config['version'] = 0.3;





