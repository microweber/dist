<?php

dd(User::all());