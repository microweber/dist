<?php

$config = array();
$config['name'] = "Button";
$config['author'] = "Microweber";
$config['no_cache'] = true;
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = 7;
$config['version'] = 0.9;
