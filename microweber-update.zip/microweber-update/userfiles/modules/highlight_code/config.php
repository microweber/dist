<?php

$config = array();
$config['name'] = "highlight_code";
$config['author'] = "Microweber";
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = 7;
$config['version'] = 1;