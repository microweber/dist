<?php

$config = array();
$config['name'] = "Settings";
$config['author'] = "Microweber";
$config['ui_admin'] = false;
$config['ui'] = false;
$config['is_system'] = true;

$config['categories'] = "admin";
$config['position'] = 4;
$config['version'] = 0.3;